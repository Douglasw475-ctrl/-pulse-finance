import { useState, useEffect } from "react";
import {
  AreaChart, Area, PieChart, Pie, Cell, BarChart, Bar,
  XAxis, YAxis, Tooltip, ResponsiveContainer
} from "recharts";

// ── Icons (inline SVGs as components) ──────────────────────────────────────
const Icon = ({ d, size = 20, stroke = "currentColor", fill = "none", strokeWidth = 1.8 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);
const HomeIcon = () => <Icon d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z" />;
const GastosIcon = () => <Icon d="M2 8h20v13H2zM16 3l-4 5-4-5" />;
const GraficosIcon = () => <Icon d="M18 20V10M12 20V4M6 20v-6" />;
const MetasIcon = () => <Icon d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm0-14v4l3 3" />;
const AddIcon = () => <Icon d="M12 5v14M5 12h14" strokeWidth={2} />;
const InsightsIcon = () => <Icon d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />;
const BellIcon = () => <Icon d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />;
const MenuIcon = () => <Icon d="M4 6h16M4 12h16M4 18h16" />;
const CloseIcon = () => <Icon d="M18 6L6 18M6 6l12 12" />;

// ── Mock Data ───────────────────────────────────────────────────────────────
const balanceHistory = [
  { d: "1 Mai", v: 6200 }, { d: "5 Mai", v: 6800 }, { d: "10 Mai", v: 7100 },
  { d: "15 Mai", v: 6900 }, { d: "20 Mai", v: 8425 }, { d: "25 Mai", v: 8100 },
  { d: "31 Mai", v: 8425 },
];

const pieData = [
  { name: "Alimentação", value: 30, color: "#f97316" },
  { name: "Transporte", value: 25, color: "#3b82f6" },
  { name: "Moradia", value: 20, color: "#22c55e" },
  { name: "Lazer", value: 15, color: "#a855f7" },
  { name: "Outros", value: 10, color: "#64748b" },
];

const barData = [
  { mes: "Jan", v: 3200 }, { mes: "Fev", v: 2800 }, { mes: "Mar", v: 3600 },
  { mes: "Abr", v: 3100 }, { mes: "Mai", v: 4154 }, { mes: "Jun", v: 0 },
];

const gastos = [
  { id: 1, nome: "Café Starbucks", cat: "Alimentação", data: "Hoje", valor: 28.50, icon: "☕", cor: "#f97316" },
  { id: 2, nome: "Uber", cat: "Transporte", data: "Hoje", valor: 38.00, icon: "🚗", cor: "#3b82f6" },
  { id: 3, nome: "Farmácia São João", cat: "Saúde", data: "Hoje", valor: 20.00, icon: "💊", cor: "#22c55e" },
  { id: 4, nome: "Mercado Zaffari", cat: "Alimentação", data: "Ontem", valor: 89.90, icon: "🛒", cor: "#f97316" },
  { id: 5, nome: "Netflix", cat: "Entretenimento", data: "Ontem", valor: 40.00, icon: "🎬", cor: "#ef4444" },
  { id: 6, nome: "Posto Ipiranga", cat: "Transporte", data: "12 Mai", valor: 56.00, icon: "⛽", cor: "#3b82f6" },
  { id: 7, nome: "Zara", cat: "Vestuário", data: "11 Mai", valor: 189.90, icon: "👗", cor: "#a855f7" },
  { id: 8, nome: "Spotify", cat: "Entretenimento", data: "10 Mai", valor: 19.90, icon: "🎵", cor: "#1db954" },
];

const metas = [
  { id: 1, nome: "Viagem dos sonhos ✈️", total: 6000, guardado: 3780, cor: "#a855f7" },
  { id: 2, nome: "Reserva de emergência", total: 10000, guardado: 4200, cor: "#22c55e" },
  { id: 3, nome: "Novo iPhone 📱", total: 8000, guardado: 2240, cor: "#3b82f6" },
];

const fmt = (v) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

// ── Sidebar nav items ───────────────────────────────────────────────────────
const NAV = [
  { id: "home", label: "Home", icon: <HomeIcon /> },
  { id: "gastos", label: "Gastos", icon: <GastosIcon /> },
  { id: "graficos", label: "Gráficos", icon: <GraficosIcon /> },
  { id: "metas", label: "Metas", icon: <MetasIcon /> },
  { id: "adicionar", label: "Adicionar", icon: <AddIcon /> },
  { id: "insights", label: "Insights", icon: <InsightsIcon /> },
];

// ══════════════════════════════════════════════════════════════════════════════
// PAGE COMPONENTS
// ══════════════════════════════════════════════════════════════════════════════

function HomePage() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <p style={{ color: "#94a3b8", fontSize: 14, margin: 0 }}>Olá! Vamos cuidar do seu dinheiro hoje? 💡</p>
          <h1 style={{ color: "#f1f5f9", fontSize: 28, fontWeight: 700, margin: "4px 0 0", fontFamily: "'Syne', sans-serif" }}>Dashboard</h1>
        </div>
        <div style={{ background: "#1e293b", borderRadius: 12, padding: 10, cursor: "pointer", color: "#94a3b8", border: "1px solid #334155" }}>
          <BellIcon />
        </div>
      </div>

      {/* Balance Card */}
      <div style={{
        background: "linear-gradient(135deg, #7c3aed 0%, #4f46e5 50%, #2563eb 100%)",
        borderRadius: 20, padding: "28px 28px 24px", position: "relative", overflow: "hidden"
      }}>
        <div style={{ position: "absolute", top: -30, right: -30, width: 120, height: 120, borderRadius: "50%", background: "rgba(255,255,255,0.06)" }} />
        <div style={{ position: "absolute", bottom: -20, left: 40, width: 80, height: 80, borderRadius: "50%", background: "rgba(255,255,255,0.04)" }} />
        <p style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, margin: "0 0 8px", letterSpacing: 1, textTransform: "uppercase" }}>Saldo atual</p>
        <h2 style={{ color: "#fff", fontSize: 36, fontWeight: 800, margin: "0 0 16px", fontFamily: "'Syne', sans-serif" }}>R$ 8.425,70</h2>
        <div style={{ display: "flex", gap: 24 }}>
          <div>
            <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, margin: "0 0 4px" }}>Entradas</p>
            <p style={{ color: "#86efac", fontSize: 16, fontWeight: 700, margin: 0 }}>R$ 12.580,00</p>
          </div>
          <div>
            <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, margin: "0 0 4px" }}>Saídas</p>
            <p style={{ color: "#fca5a5", fontSize: 16, fontWeight: 700, margin: 0 }}>R$ 4.154,30</p>
          </div>
        </div>
      </div>

      {/* Mini Chart */}
      <div style={{ background: "#0f172a", borderRadius: 20, padding: "20px 16px 12px", border: "1px solid #1e293b" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
          <p style={{ color: "#f1f5f9", fontWeight: 600, margin: 0 }}>Resumo do mês</p>
          <span style={{ color: "#7c3aed", fontSize: 13 }}>Maio ▾</span>
        </div>
        <ResponsiveContainer width="100%" height={120}>
          <AreaChart data={balanceHistory}>
            <defs>
              <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#7c3aed" stopOpacity={0.4} />
                <stop offset="95%" stopColor="#7c3aed" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="d" hide />
            <YAxis hide />
            <Tooltip
              contentStyle={{ background: "#1e293b", border: "none", borderRadius: 8, color: "#f1f5f9", fontSize: 12 }}
              formatter={(v) => [fmt(v), ""]}
            />
            <Area type="monotone" dataKey="v" stroke="#7c3aed" strokeWidth={2.5} fill="url(#grad)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Top Category */}
      <div style={{ background: "#0f172a", borderRadius: 20, padding: 20, border: "1px solid #1e293b" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <p style={{ color: "#f1f5f9", fontWeight: 600, margin: 0 }}>Maior categoria</p>
          <span style={{ color: "#7c3aed", fontSize: 13, cursor: "pointer" }}>Ver todas →</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ background: "#f97316", borderRadius: 14, width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>🍔</div>
          <div style={{ flex: 1 }}>
            <p style={{ color: "#f1f5f9", fontWeight: 600, margin: "0 0 4px" }}>Alimentação</p>
            <div style={{ background: "#1e293b", borderRadius: 99, height: 6, overflow: "hidden" }}>
              <div style={{ width: "30%", height: "100%", background: "linear-gradient(90deg, #f97316, #fb923c)", borderRadius: 99 }} />
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <p style={{ color: "#f1f5f9", fontWeight: 700, margin: 0 }}>R$ 1.248,90</p>
            <p style={{ color: "#94a3b8", fontSize: 12, margin: 0 }}>30,1% do total</p>
          </div>
        </div>
      </div>

      {/* Savings */}
      <div style={{ background: "#0f172a", borderRadius: 20, padding: 20, border: "1px solid #1e293b" }}>
        <p style={{ color: "#94a3b8", fontSize: 13, margin: "0 0 8px" }}>Economia do mês</p>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <p style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0, fontFamily: "'Syne', sans-serif" }}>R$ 2.350,50</p>
            <p style={{ color: "#86efac", fontSize: 13, margin: "4px 0 0" }}>+18,6% em relação ao mês passado</p>
          </div>
          <div style={{ position: "relative", width: 70, height: 70 }}>
            <svg viewBox="0 0 36 36" style={{ transform: "rotate(-90deg)", width: 70, height: 70 }}>
              <circle cx="18" cy="18" r="15.9" fill="none" stroke="#1e293b" strokeWidth="3" />
              <circle cx="18" cy="18" r="15.9" fill="none" stroke="#7c3aed" strokeWidth="3"
                strokeDasharray={`${38 * 1} ${100 - 38}`} strokeLinecap="round" />
            </svg>
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ color: "#f1f5f9", fontSize: 14, fontWeight: 700 }}>38%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function GastosPage() {
  const grupos = [...new Set(gastos.map((g) => g.data))];
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 700, margin: 0, fontFamily: "'Syne', sans-serif" }}>Gastos</h1>
        <div style={{ background: "#7c3aed", borderRadius: 12, padding: "8px 14px", cursor: "pointer", color: "#fff", fontSize: 13, fontWeight: 600 }}>+ Novo</div>
      </div>

      {/* Filter chips */}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {["Todos", "Alimentação", "Transporte", "Saúde", "Lazer"].map((f, i) => (
          <span key={f} style={{
            padding: "6px 14px", borderRadius: 99, fontSize: 13, cursor: "pointer", fontWeight: 500,
            background: i === 0 ? "#7c3aed" : "#1e293b",
            color: i === 0 ? "#fff" : "#94a3b8",
            border: i === 0 ? "none" : "1px solid #334155"
          }}>{f}</span>
        ))}
      </div>

      {/* Expense groups */}
      {grupos.map((grupo) => (
        <div key={grupo}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
            <p style={{ color: "#94a3b8", fontSize: 13, fontWeight: 600, margin: 0, textTransform: "uppercase", letterSpacing: 0.8 }}>{grupo}</p>
            <p style={{ color: "#94a3b8", fontSize: 13, margin: 0 }}>
              {fmt(gastos.filter((g) => g.data === grupo).reduce((s, g) => s + g.valor, 0))}
            </p>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {gastos.filter((g) => g.data === grupo).map((item) => (
              <div key={item.id} style={{
                background: "#0f172a", border: "1px solid #1e293b", borderRadius: 16,
                padding: "14px 16px", display: "flex", alignItems: "center", gap: 14,
                cursor: "pointer", transition: "border-color 0.2s"
              }}>
                <div style={{ background: item.cor + "22", borderRadius: 12, width: 42, height: 42, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>
                  {item.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{ color: "#f1f5f9", fontWeight: 600, margin: 0, fontSize: 14 }}>{item.nome}</p>
                  <p style={{ color: "#64748b", fontSize: 12, margin: "2px 0 0" }}>{item.cat}</p>
                </div>
                <p style={{ color: "#f1f5f9", fontWeight: 700, margin: 0 }}>- {fmt(item.valor)}</p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function GraficosPage() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 700, margin: 0, fontFamily: "'Syne', sans-serif" }}>Gráficos</h1>

      {/* Period selector */}
      <div style={{ display: "flex", gap: 8 }}>
        {["Mensal", "Semestral", "Anual"].map((p, i) => (
          <button key={p} style={{
            padding: "8px 18px", borderRadius: 10, border: "none", cursor: "pointer", fontWeight: 600, fontSize: 13,
            background: i === 0 ? "#7c3aed" : "#1e293b", color: i === 0 ? "#fff" : "#64748b"
          }}>{p}</button>
        ))}
      </div>

      {/* Pie Chart */}
      <div style={{ background: "#0f172a", borderRadius: 20, padding: 24, border: "1px solid #1e293b" }}>
        <p style={{ color: "#f1f5f9", fontWeight: 600, margin: "0 0 4px" }}>Total gasto</p>
        <p style={{ color: "#7c3aed", fontSize: 28, fontWeight: 800, margin: "0 0 20px", fontFamily: "'Syne', sans-serif" }}>R$ 4.154,30</p>
        <div style={{ display: "flex", justifyContent: "center" }}>
          <PieChart width={200} height={200}>
            <Pie data={pieData} cx={95} cy={95} innerRadius={55} outerRadius={90} paddingAngle={3} dataKey="value">
              {pieData.map((entry) => (
                <Cell key={entry.name} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip contentStyle={{ background: "#1e293b", border: "none", borderRadius: 8, color: "#f1f5f9", fontSize: 12 }} />
          </PieChart>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 16 }}>
          {pieData.map((item) => (
            <div key={item.name} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ width: 10, height: 10, borderRadius: "50%", background: item.color }} />
                <span style={{ color: "#94a3b8", fontSize: 13 }}>{item.name}</span>
                <span style={{ color: "#475569", fontSize: 12 }}>{item.value}%</span>
              </div>
              <span style={{ color: "#f1f5f9", fontWeight: 600, fontSize: 13 }}>
                {fmt(4154.30 * item.value / 100)}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Bar chart */}
      <div style={{ background: "#0f172a", borderRadius: 20, padding: 24, border: "1px solid #1e293b" }}>
        <p style={{ color: "#f1f5f9", fontWeight: 600, margin: "0 0 16px" }}>Comparativo mensal</p>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={barData} barSize={20}>
            <XAxis dataKey="mes" tick={{ fill: "#64748b", fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis hide />
            <Tooltip contentStyle={{ background: "#1e293b", border: "none", borderRadius: 8, color: "#f1f5f9", fontSize: 12 }} formatter={(v) => [fmt(v), ""]} />
            <Bar dataKey="v" radius={[6, 6, 0, 0]}>
              {barData.map((_, i) => (
                <Cell key={i} fill={i === 4 ? "#7c3aed" : "#1e293b"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function MetasPage() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 700, margin: 0, fontFamily: "'Syne', sans-serif" }}>Metas</h1>
        <div style={{ background: "#7c3aed", borderRadius: 12, padding: "8px 14px", cursor: "pointer", color: "#fff", fontSize: 13, fontWeight: 600 }}>+ Nova</div>
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        {["Minhas metas", "Concluídas"].map((t, i) => (
          <button key={t} style={{
            flex: 1, padding: "10px", borderRadius: 12, border: "none", cursor: "pointer", fontWeight: 600, fontSize: 13,
            background: i === 0 ? "#7c3aed" : "#1e293b", color: i === 0 ? "#fff" : "#64748b"
          }}>{t}</button>
        ))}
      </div>

      {metas.map((meta) => {
        const pct = Math.round((meta.guardado / meta.total) * 100);
        return (
          <div key={meta.id} style={{ background: "#0f172a", borderRadius: 20, padding: 22, border: "1px solid #1e293b" }}>
            <p style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 16, margin: "0 0 12px" }}>{meta.nome}</p>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
              <span style={{ color: "#94a3b8", fontSize: 13 }}>Meta: {fmt(meta.total)}</span>
              <span style={{ color: meta.cor, fontWeight: 700, fontSize: 14 }}>{pct}%</span>
            </div>
            <div style={{ background: "#1e293b", borderRadius: 99, height: 8, overflow: "hidden", marginBottom: 10 }}>
              <div style={{ width: `${pct}%`, height: "100%", background: `linear-gradient(90deg, ${meta.cor}99, ${meta.cor})`, borderRadius: 99, transition: "width 0.8s ease" }} />
            </div>
            <p style={{ color: "#64748b", fontSize: 13, margin: 0 }}>{fmt(meta.guardado)} guardados</p>
          </div>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function AdicionarPage() {
  const [form, setForm] = useState({ nome: "", valor: "", categoria: "Alimentação", data: "", tipo: "saida", nota: "" });
  const [saved, setSaved] = useState(false);

  const handle = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const submit = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
    setForm({ nome: "", valor: "", categoria: "Alimentação", data: "", tipo: "saida", nota: "" });
  };

  const inputStyle = {
    background: "#0f172a", border: "1px solid #334155", borderRadius: 12,
    padding: "12px 16px", color: "#f1f5f9", fontSize: 14, width: "100%",
    outline: "none", boxSizing: "border-box", fontFamily: "inherit"
  };
  const labelStyle = { color: "#94a3b8", fontSize: 13, marginBottom: 6, display: "block" };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
      <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 700, margin: 0, fontFamily: "'Syne', sans-serif" }}>Adicionar Gasto</h1>

      {saved && (
        <div style={{ background: "#14532d", border: "1px solid #22c55e", borderRadius: 14, padding: "14px 18px", color: "#86efac", fontWeight: 600 }}>
          ✅ Gasto adicionado com sucesso!
        </div>
      )}

      {/* Tipo */}
      <div>
        <label style={labelStyle}>Tipo de lançamento</label>
        <div style={{ display: "flex", gap: 10 }}>
          {["saida", "entrada"].map((t) => (
            <button key={t} onClick={() => handle("tipo", t)} style={{
              flex: 1, padding: "12px", borderRadius: 12, border: "none", cursor: "pointer", fontWeight: 600, fontSize: 13,
              background: form.tipo === t ? (t === "saida" ? "#7c3aed" : "#15803d") : "#1e293b",
              color: form.tipo === t ? "#fff" : "#64748b"
            }}>{t === "saida" ? "💸 Saída" : "💰 Entrada"}</button>
          ))}
        </div>
      </div>

      <div>
        <label style={labelStyle}>Nome do gasto</label>
        <input style={inputStyle} placeholder="Ex: Mercado, Uber, Netflix..." value={form.nome} onChange={(e) => handle("nome", e.target.value)} />
      </div>

      <div>
        <label style={labelStyle}>Valor (R$)</label>
        <input style={{ ...inputStyle, fontSize: 22, fontWeight: 700 }} placeholder="0,00" value={form.valor} onChange={(e) => handle("valor", e.target.value)} type="number" />
      </div>

      <div>
        <label style={labelStyle}>Categoria</label>
        <select style={{ ...inputStyle, appearance: "none" }} value={form.categoria} onChange={(e) => handle("categoria", e.target.value)}>
          {["Alimentação", "Transporte", "Moradia", "Saúde", "Lazer", "Entretenimento", "Vestuário", "Outros"].map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </div>

      <div>
        <label style={labelStyle}>Data</label>
        <input style={inputStyle} type="date" value={form.data} onChange={(e) => handle("data", e.target.value)} />
      </div>

      <div>
        <label style={labelStyle}>Nota (opcional)</label>
        <textarea style={{ ...inputStyle, resize: "vertical", minHeight: 80 }} placeholder="Detalhes..." value={form.nota} onChange={(e) => handle("nota", e.target.value)} />
      </div>

      <button onClick={submit} style={{
        background: "linear-gradient(135deg, #7c3aed, #4f46e5)", border: "none", borderRadius: 14,
        padding: "16px", color: "#fff", fontSize: 16, fontWeight: 700, cursor: "pointer", width: "100%"
      }}>Salvar gasto</button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
function InsightsPage() {
  const insights = [
    { icon: "🛵", titulo: "Delivery", desc: "Você gastou R$ 480,00 em delivery este mês.", saving: "-15%", cor: "#f97316" },
    { icon: "📺", titulo: "Assinaturas", desc: "Você tem 3 assinaturas ativas. Avalie se usa todas.", saving: "-8%", cor: "#a855f7" },
    { icon: "🛍️", titulo: "Compras por impulso", desc: "Você gastou R$ 260,00 com compras não planejadas.", saving: "-10%", cor: "#ef4444" },
  ];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 700, margin: 0, fontFamily: "'Syne', sans-serif" }}>Insights</h1>

      {/* Hero insight */}
      <div style={{
        background: "linear-gradient(135deg, #1e293b, #0f172a)", borderRadius: 24,
        padding: 28, border: "1px solid #334155", textAlign: "center"
      }}>
        <div style={{ fontSize: 56, marginBottom: 12 }}>🐷</div>
        <p style={{ color: "#94a3b8", fontSize: 14, margin: "0 0 8px" }}>Você pode economizar</p>
        <p style={{ color: "#f1f5f9", fontSize: 32, fontWeight: 800, margin: "0 0 12px", fontFamily: "'Syne', sans-serif" }}>até R$ 320,00<br /><span style={{ fontSize: 18, color: "#94a3b8" }}>por mês</span></p>
        <p style={{ color: "#64748b", fontSize: 13, margin: 0 }}>Analisamos seus gastos e encontramos oportunidades para economizar.</p>
      </div>

      {/* Insights list */}
      <div>
        <p style={{ color: "#94a3b8", fontSize: 13, fontWeight: 600, margin: "0 0 14px", textTransform: "uppercase", letterSpacing: 0.8 }}>Onde você pode economizar</p>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {insights.map((item) => (
            <div key={item.titulo} style={{
              background: "#0f172a", border: "1px solid #1e293b", borderRadius: 16,
              padding: "16px 18px", display: "flex", alignItems: "center", gap: 14
            }}>
              <div style={{ background: item.cor + "22", borderRadius: 12, width: 44, height: 44, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, flexShrink: 0 }}>
                {item.icon}
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ color: "#f1f5f9", fontWeight: 700, margin: "0 0 4px", fontSize: 14 }}>{item.titulo}</p>
                <p style={{ color: "#64748b", fontSize: 12, margin: 0 }}>{item.desc}</p>
              </div>
              <div style={{ background: "#14532d", borderRadius: 8, padding: "4px 10px", color: "#86efac", fontWeight: 700, fontSize: 13, flexShrink: 0 }}>
                {item.saving}
              </div>
            </div>
          ))}
        </div>
      </div>

      <button style={{
        background: "linear-gradient(135deg, #7c3aed, #4f46e5)", border: "none", borderRadius: 14,
        padding: "16px", color: "#fff", fontSize: 15, fontWeight: 700, cursor: "pointer", width: "100%"
      }}>Ver todas as dicas</button>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// MAIN APP
// ══════════════════════════════════════════════════════════════════════════════

const PAGES = { home: HomePage, gastos: GastosPage, graficos: GraficosPage, metas: MetasPage, adicionar: AdicionarPage, insights: InsightsPage };

export default function App() {
  const [active, setActive] = useState("home");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const PageComponent = PAGES[active];

  const navigate = (id) => {
    setActive(id);
    setSidebarOpen(false);
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@400;500;600;700&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #020617; font-family: 'DM Sans', sans-serif; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: #0f172a; }
        ::-webkit-scrollbar-thumb { background: #334155; border-radius: 99px; }
        input, select, textarea, button { font-family: 'DM Sans', sans-serif; }
        input[type=date]::-webkit-calendar-picker-indicator { filter: invert(0.5); }
      `}</style>

      <div style={{ display: "flex", height: "100vh", overflow: "hidden", background: "#020617" }}>

        {/* ── Sidebar overlay (mobile) */}
        {sidebarOpen && (
          <div onClick={() => setSidebarOpen(false)} style={{
            position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 40, backdropFilter: "blur(4px)"
          }} />
        )}

        {/* ── Sidebar ─────────────────────────────────────────── */}
        <aside style={{
          width: 240, background: "#060f1e", borderRight: "1px solid #1e293b",
          display: "flex", flexDirection: "column", padding: "28px 16px", gap: 8,
          flexShrink: 0, overflowY: "auto",
          // Mobile: slide over
          position: window.innerWidth < 768 ? "fixed" : "relative",
          top: 0, left: 0, bottom: 0, zIndex: 50,
          transform: window.innerWidth < 768 ? (sidebarOpen ? "translateX(0)" : "translateX(-100%)") : "translateX(0)",
          transition: "transform 0.3s cubic-bezier(.4,0,.2,1)"
        }}>
          {/* Logo */}
          <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "0 8px 16px", borderBottom: "1px solid #1e293b", marginBottom: 8 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 10, background: "linear-gradient(135deg, #7c3aed, #4f46e5)",
              display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 900, fontSize: 18, fontFamily: "'Syne', sans-serif"
            }}>P</div>
            <div>
              <p style={{ color: "#f1f5f9", fontWeight: 800, fontSize: 16, margin: 0, fontFamily: "'Syne', sans-serif" }}>Pulse Finance</p>
              <p style={{ color: "#475569", fontSize: 11, margin: 0 }}>Finanças pessoais</p>
            </div>
            {window.innerWidth < 768 && (
              <button onClick={() => setSidebarOpen(false)} style={{ background: "none", border: "none", color: "#64748b", cursor: "pointer", marginLeft: "auto" }}>
                <CloseIcon />
              </button>
            )}
          </div>

          {/* Nav items */}
          {NAV.map((item) => {
            const isActive = active === item.id;
            return (
              <button key={item.id} onClick={() => navigate(item.id)} style={{
                display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderRadius: 14,
                border: "none", cursor: "pointer", textAlign: "left", width: "100%", transition: "all 0.15s",
                background: isActive ? "#7c3aed22" : "transparent",
                color: isActive ? "#a78bfa" : "#64748b",
                borderLeft: isActive ? "3px solid #7c3aed" : "3px solid transparent"
              }}>
                <span style={{ opacity: isActive ? 1 : 0.6 }}>{item.icon}</span>
                <span style={{ fontWeight: isActive ? 700 : 500, fontSize: 14 }}>{item.label}</span>
              </button>
            );
          })}

          {/* User at bottom */}
          <div style={{ marginTop: "auto", background: "#0f172a", borderRadius: 14, padding: "12px 14px", display: "flex", alignItems: "center", gap: 10, border: "1px solid #1e293b" }}>
            <div style={{ width: 34, height: 34, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #ec4899)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 14 }}>P</div>
            <div>
              <p style={{ color: "#f1f5f9", fontWeight: 600, fontSize: 13, margin: 0 }}>Pedro</p>
              <p style={{ color: "#475569", fontSize: 11, margin: 0 }}>Plano Pro</p>
            </div>
          </div>
        </aside>

        {/* ── Main content ──────────────────────────────────────── */}
        <main style={{ flex: 1, overflowY: "auto", padding: "28px 24px", maxWidth: "100%" }}>
          {/* Mobile topbar */}
          <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 24, position: window.innerWidth < 768 ? "sticky" : "relative", top: 0, background: "#020617", paddingBottom: 8, zIndex: 10 }}>
            {window.innerWidth < 768 && (
              <button onClick={() => setSidebarOpen(true)} style={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 10, padding: 8, cursor: "pointer", color: "#94a3b8" }}>
                <MenuIcon />
              </button>
            )}
            <div style={{ display: "flex", gap: 6 }}>
              {NAV.map((n) => n.id === active && (
                <div key={n.id} style={{ display: "flex", alignItems: "center", gap: 6, color: "#94a3b8", fontSize: 13 }}>
                  <span style={{ color: "#475569" }}>Início</span>
                  <span style={{ color: "#334155" }}>›</span>
                  <span style={{ color: "#f1f5f9", fontWeight: 600 }}>{n.label}</span>
                </div>
              ))}
            </div>
          </div>

          <div style={{ maxWidth: 720, margin: "0 auto" }}>
            <PageComponent />
          </div>
        </main>
      </div>
    </>
  );
}
